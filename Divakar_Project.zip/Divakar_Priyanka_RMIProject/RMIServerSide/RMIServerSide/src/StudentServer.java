//// Author 1 - Priyanka Dassani
//// Author 2 - Divakar Mer
////Course: CPE545
////Project - Student Query RMI Communication
//
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;

public class StudentServer {
	//  Host Name to connect interfaces
	private static String hostName = "10.0.0.111";  //"155.246.215.168" ; 
	private static int remotePort = 1099;
    private static final String bindString = "rmi://"+hostName+":"+remotePort+"/search";

	 public static void main(String[] argv) throws RemoteException {
	        StudentDetails Student = new StudentDetails();
	        try { 
	            LocateRegistry.createRegistry(remotePort);
	            System.out.println("java RMI registry Interface created.");
	        } 
			catch (RemoteException e) {
	            System.out.println("java RMI registry Interface already exists.");
	        }	        
 
	        try {
	            Naming.bind(bindString , Student);
	            System.out.println("Server is ready to connect:" + bindString );
				System.out.println("Start your client");
	        }
			catch (RemoteException e) {
	        	System.out.println("Incorrect Remote Method Call ");
	            e.printStackTrace();
	        } catch (MalformedURLException e) {
	        	System.out.println("Incorrect URL formed");
	            e.printStackTrace();
	        } catch (Exception e) {
	            System.out.println("StudentDetails Server not connected: " + e);
	        }
	    }

}