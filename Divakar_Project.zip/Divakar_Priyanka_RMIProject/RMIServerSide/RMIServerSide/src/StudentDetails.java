  import java.util.*;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public  class StudentDetails extends UnicastRemoteObject  implements  InterfaceRegistry{

	public StudentDetails() throws RemoteException {
		// TODO Auto-generated constructor stub
	}
public List<String> StudentFullNameGet(String FirstName) {
		
		//List of Class Students
		List <String> list = new ArrayList<String>(); 
        list.add("Divakar Mer"); 
        list.add("Priyanka Dassani"); 
        list.add("Abc Def"); 
        list.add("Ghi Jkl"); 
        list.add("Mno Pqr"); 
        list.add("Mno Rqr"); 
        list.add("Mno Qqr"); 
        list.add("Stu Vwx"); 
        list.add("Bcd Efg"); 
        list.add("Jcd Ofg");
        list.add("Wcd Rfg");
        list.add("Bacd Eeefg");
       

	    //Temporary List
		List <String> studentlist = new ArrayList<String>(); 
	    
		for (String string : list) {
		    if(string.matches("(?i)("+ FirstName + ").*")){
	 		   studentlist.add(string);
 		    }
	    }	   
		return studentlist;
	}

}
