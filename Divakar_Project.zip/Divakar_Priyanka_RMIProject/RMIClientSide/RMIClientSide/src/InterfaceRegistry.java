import java.util.*;
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface InterfaceRegistry extends Remote{
	//Common interface between Server and Client
		public List<String> StudentFullNameGet(String FirstName) throws RemoteException;
}
