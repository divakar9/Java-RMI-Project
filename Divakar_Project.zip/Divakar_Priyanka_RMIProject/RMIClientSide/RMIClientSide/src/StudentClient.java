//// Author 1 - Priyanka Dassani
//// Author 2 - Divakar Mer
////Course: CPE545
////Project - Student Query RMI Communication

import java.util.*;
import java.net.MalformedURLException;
import java.rmi.*;

public class StudentClient {
    // Host Name to connect Server
	private static String remoteHostName =   "10.0.0.111"; //155.246.215.168  //12.0.0.1
	private static int remotePort = 1099;
    private static final String connectionString = "rmi://"+remoteHostName+":"+remotePort+"/search";

	public static void main(String[] args) {
        InterfaceRegistry Student= null;
        try {
            System.out.println("Connecting to Server at : " + connectionString);
            Student = (InterfaceRegistry)Naming.lookup(connectionString);
        } catch (MalformedURLException e1) {
        	System.out.println("Incorrect URL formed");
            e1.printStackTrace();
        } catch (RemoteException e1) {
        	System.out.println("Incorrect Remote Method Call ");
            e1.printStackTrace();
        } catch (NotBoundException e1) {
        	System.out.println("No associated Binding");
            e1.printStackTrace();
        }

        List<String> result = new ArrayList<String>();
        try {
			do{
				Scanner scanner = new Scanner( System.in );
				System.out.print( "Enter First Name of the student: " );
				String FirstName = scanner.nextLine();
				result = Student.StudentFullNameGet(FirstName);
				if(result != null && !result.isEmpty())
				{
				System.out.println("Students with the names are:" + result + "\n");
				} else {
				System.out.println("No details found for the given first name\n");
				}
			}while(true);
        } catch (RemoteException e1) {
        	System.out.println("Incorrect Remote Method Call ");
            e1.printStackTrace();
        }
        System.exit(0);
	}

}

